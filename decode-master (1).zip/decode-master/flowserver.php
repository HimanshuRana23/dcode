<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database configuration
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'flow_db';

// Create connection
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    die(json_encode(['error' => 'Connection failed: ' . $conn->connect_error]));
}

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Handle GET request (fetch flow)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['id'])) {
        $id = $conn->real_escape_string($_GET['id']);
        
        $query = "SELECT * FROM flows WHERE id = '$id'";
        $result = $conn->query($query);
        
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $flow = json_decode($row['flow_data'], true);
            $nodeConfigs = json_decode($row['node_configs'], true) ?? [];
            
            // Merge node configurations with flow data
            if (isset($flow['nodes'])) {
                foreach ($flow['nodes'] as &$node) {
                    if (isset($nodeConfigs[$node['id']])) {
                        $node['data']['config'] = $nodeConfigs[$node['id']];
                    }
                }
            }
            
            echo json_encode([
                'name' => $row['name'],
                'flow' => $flow
            ]);
        } else {
            echo json_encode(['error' => 'Flow not found']);
        }
    } else {
        // List all flows
        $query = "SELECT id, name, created_at FROM flows ORDER BY created_at DESC";
        $result = $conn->query($query);
        
        $flows = [];
        while ($row = $result->fetch_assoc()) {
            $flows[] = $row;
        }
        
        echo json_encode($flows);
    }
}

// Handle POST request (save flow)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data) {
        echo json_encode(['error' => 'Invalid JSON data']);
        exit();
    }
    
    $name = $conn->real_escape_string($data['name']);
    $flowData = $conn->real_escape_string(json_encode($data['flow'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    
    // Extract node configurations
    $nodeConfigs = [];
    if (isset($data['flow']['nodes'])) {
        foreach ($data['flow']['nodes'] as $node) {
            if (isset($node['data']['config'])) {
                $nodeConfigs[$node['id']] = $node['data']['config'];
            }
        }
    }
    $nodeConfigsJson = $conn->real_escape_string(json_encode($nodeConfigs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    
    if (isset($data['id']) && $data['id'] !== 'new') {
        // Update existing flow
        $id = $conn->real_escape_string($data['id']);
        $query = "UPDATE flows SET 
                  name = '$name', 
                  flow_data = '$flowData',
                  node_configs = '$nodeConfigsJson',
                  updated_at = NOW() 
                  WHERE id = '$id'";
                  
        if ($conn->query($query)) {
            echo json_encode(['success' => true, 'id' => $id]);
        } else {
            echo json_encode(['error' => 'Error updating flow: ' . $conn->error]);
        }
    } else {
        // Create new flow
        $query = "INSERT INTO flows (name, flow_data, node_configs, created_at, updated_at) 
                  VALUES ('$name', '$flowData', '$nodeConfigsJson', NOW(), NOW())";
                  
        if ($conn->query($query)) {
            echo json_encode(['success' => true, 'id' => $conn->insert_id]);
        } else {
            echo json_encode(['error' => 'Error creating flow: ' . $conn->error]);
        }
    }
}

$conn->close();
?>
