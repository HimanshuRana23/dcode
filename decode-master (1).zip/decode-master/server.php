<?php
// Start output buffering
ob_start();

// Error handling setup
error_reporting(E_ALL);
ini_set('display_errors', 0); // Disable display of errors
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Function to handle fatal errors
function handleFatalError() {
    $error = error_get_last();
    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        ob_clean(); // Clear any output
        sendJsonResponse(false, [], 'Fatal error: ' . $error['message'], 500);
    }
}

// Register shutdown function
register_shutdown_function('handleFatalError');

// CORS and headers setup
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

// Handle preflight (OPTIONS) request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_clean();
    http_response_code(204);
    exit;
}

// Define directories
$BASE_DIR = __DIR__ . '/data';
$DIRS = [
    'forms' => "$BASE_DIR/forms",
    'formdrilldown' => "$BASE_DIR/formdrilldown",
    'form2' => "$BASE_DIR/form2",
    'api' => "$BASE_DIR/api"
];

// Ensure directories exist
foreach ($DIRS as $dir) {
    if (!is_dir($dir)) {
        if (!mkdir($dir, 0777, true)) {
            error_log("Failed to create directory: $dir");
            sendJsonResponse(false, [], "Failed to create directory: $dir", 500);
        }
    }
}

// URI parser
$requestUri = $_SERVER['REQUEST_URI'];
$scriptName = $_SERVER['SCRIPT_NAME'];
$uri = str_replace($scriptName, '', $requestUri);
$uri = strtok($uri, '?');
$method = $_SERVER['REQUEST_METHOD'];

// Helpers
function generateFileName($prefix = 'form') {
    return $prefix . '_' . date('Y-m-d_H-i-s') . '.json';
}

function readJsonFiles($dir) {
    $forms = [];
    foreach (glob("$dir/*.json") as $file) {
        $forms[] = json_decode(file_get_contents($file), true);
    }
    return $forms;
}

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'api_editor_db');

// Database connection and initialization
function initializeDatabase() {
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS);
        if ($conn->connect_error) {
            throw new Exception("Connection failed: " . $conn->connect_error);
        }

        // Create database if it doesn't exist
        $conn->query("CREATE DATABASE IF NOT EXISTS " . DB_NAME);
        $conn->select_db(DB_NAME);

        // Create table if it doesn't exist
        $sql = "CREATE TABLE IF NOT EXISTS api_files (
            id INT AUTO_INCREMENT PRIMARY KEY,
            file_name VARCHAR(255) NOT NULL,
            file_path VARCHAR(255) NOT NULL,
            content LONGTEXT NOT NULL,
            editable_lines TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            last_accessed TIMESTAMP NULL,
            is_active TINYINT(1) DEFAULT 1,
            UNIQUE KEY unique_file_name (file_name)
        )";

        if (!$conn->query($sql)) {
            throw new Exception("Failed to create table: " . $conn->error);
        }

        $conn->close();
        return true;
    } catch (Exception $e) {
        error_log("Database initialization error: " . $e->getMessage());
        return false;
    }
}

// Database connection
function getDbConnection() {
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($conn->connect_error) {
            error_log("Database connection failed: " . $conn->connect_error);
            throw new Exception("Connection failed: " . $conn->connect_error);
        }
        return $conn;
    } catch (Exception $e) {
        error_log("Database error: " . $e->getMessage());
        sendJsonResponse(false, [], 'Database connection failed: ' . $e->getMessage(), 500);
    }
}

// Initialize database on startup
if (!initializeDatabase()) {
    error_log("Failed to initialize database");
    sendJsonResponse(false, [], 'Failed to initialize database', 500);
}

try {
    // ROUTES
    if ($uri === '/api/save-form' && $method === 'POST') {
        $data = json_decode(file_get_contents("php://input"), true);
        if (!$data) {
            http_response_code(400);
            echo json_encode(["success" => false, "error" => "Invalid JSON input"]);
            exit;
        }
        $submission = array_merge([
            "id" => time(),
            "timestamp" => date('c')
        ], $data);
        $fileName = generateFileName('form');
        file_put_contents($DIRS['forms'] . "/$fileName", json_encode($submission, JSON_PRETTY_PRINT));
        echo json_encode(["success" => true, "message" => "Form saved", "fileName" => $fileName, "submissionId" => $submission['id']]);

    } elseif ($uri === '/api/save-drilldown' && $method === 'POST') {
        $data = json_decode(file_get_contents("php://input"), true);
        if (!$data) {
            http_response_code(400);
            echo json_encode(["success" => false, "error" => "Invalid JSON input"]);
            exit;
        }
        $submission = array_merge([
            "id" => time(),
            "timestamp" => date('c')
        ], $data);
        $fileName = generateFileName('drilldown');
        file_put_contents($DIRS['formdrilldown'] . "/$fileName", json_encode($submission, JSON_PRETTY_PRINT));
        echo json_encode(["success" => true, "message" => "Drilldown form saved", "fileName" => $fileName, "submissionId" => $submission['id']]);

    } elseif ($uri === '/api/regular-forms' && $method === 'GET') {
        echo json_encode(["success" => true, "forms" => readJsonFiles($DIRS['forms'])]);

    } elseif ($uri === '/api/drilldown-forms' && $method === 'GET') {
        echo json_encode(["success" => true, "forms" => readJsonFiles($DIRS['formdrilldown'])]);

    } elseif ($uri === '/api/save-api' && $method === 'POST') {
        try {
            $input = json_decode(file_get_contents('php://input'), true);
            if (!isset($input['code'])) {
                sendJsonResponse(false, [], 'No code provided', 400);
            }

            $timestamp = time();
            $fileName = isset($input['fileName']) && !empty($input['fileName']) ? $input['fileName'] : "api_{$timestamp}.php";
            $filePath = $DIRS['api'] . '/' . $fileName;
            $editableLines = isset($input['editableLines']) ? $input['editableLines'] : '';
            $usecase = isset($input['usecase']) ? $input['usecase'] : '';

            // First, try to save the file
            if (file_put_contents($filePath, $input['code'])) {
                // File saved successfully, now try database operations
                try {
                    $conn = getDbConnection();
                    $stmt = $conn->prepare("INSERT INTO api_files (file_name, file_path, content, editable_lines, usecase) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE content = ?, editable_lines = ?, usecase = ?, updated_at = CURRENT_TIMESTAMP");
                    if (!$stmt) {
                        error_log("Prepare failed: " . $conn->error);
                        // Continue without database - at least the file is saved
                        sendJsonResponse(true, [
                            'fileName' => $fileName,
                            'message' => 'API code saved successfully (database operation skipped)'
                        ]);
                    } else {
                        $stmt->bind_param("ssssssss", $fileName, $filePath, $input['code'], $editableLines, $usecase, $input['code'], $editableLines, $usecase);
                        
                        if ($stmt->execute()) {
                            sendJsonResponse(true, [
                                'fileName' => $fileName,
                                'message' => 'API code saved successfully'
                            ]);
                        } else {
                            error_log("Execute failed: " . $stmt->error);
                            // Continue without database - at least the file is saved
                            sendJsonResponse(true, [
                                'fileName' => $fileName,
                                'message' => 'API code saved successfully (database operation skipped)'
                            ]);
                        }
                        $stmt->close();
                    }
                    $conn->close();
                } catch (Exception $dbError) {
                    error_log("Database error: " . $dbError->getMessage());
                    // Continue without database - at least the file is saved
                    sendJsonResponse(true, [
                        'fileName' => $fileName,
                        'message' => 'API code saved successfully (database operation skipped)'
                    ]);
                }
            } else {
                error_log("Failed to write file: $filePath");
                sendJsonResponse(false, [], 'Failed to save API code', 500);
            }
        } catch (Exception $e) {
            error_log("Save API error: " . $e->getMessage());
            if (isset($filePath) && file_exists($filePath)) {
                unlink($filePath);
            }
            sendJsonResponse(false, [], 'Error saving API: ' . $e->getMessage(), 500);
        }

    } elseif ($uri === '/api/list-apis' && $method === 'GET') {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            sendJsonResponse(false, [], 'Method not allowed', 405);
        }

        $conn = getDbConnection();
        $result = $conn->query("SELECT id, file_name, created_at as timestamp, editable_lines, usecase FROM api_files WHERE is_active = 1 ORDER BY created_at DESC");
        
        if (!$result) {
            error_log("Query failed: " . $conn->error);
            throw new Exception("Database query failed: " . $conn->error);
        }
        
        $apis = [];
        while ($row = $result->fetch_assoc()) {
            $filePath = $DIRS['api'] . '/' . $row['file_name'];
            $apis[] = [
                'id' => $row['id'],
                'fileName' => $row['file_name'],
                'timestamp' => strtotime($row['created_at']),
                'size' => file_exists($filePath) ? filesize($filePath) : 0,
                'editableLines' => $row['editable_lines'],
                'usecase' => $row['usecase']
            ];
        }
        
        sendJsonResponse(true, ['apis' => $apis]);
        $conn->close();

    } elseif ($uri === '/api/delete-api' && $method === 'POST') {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            sendJsonResponse(false, [], 'Method not allowed', 405);
        }

        $input = json_decode(file_get_contents('php://input'), true);
        if (!isset($input['fileName'])) {
            sendJsonResponse(false, [], 'No filename provided', 400);
        }

        $conn = getDbConnection();
        $filePath = $DIRS['api'] . '/' . $input['fileName'];

        // Soft delete in database
        $stmt = $conn->prepare("UPDATE api_files SET is_active = 0 WHERE file_name = ?");
        if (!$stmt) {
            error_log("Prepare failed: " . $conn->error);
            throw new Exception("Database prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param("s", $input['fileName']);
        
        if ($stmt->execute()) {
            // Delete physical file
            if (file_exists($filePath) && unlink($filePath)) {
                sendJsonResponse(true, ['message' => 'API file deleted successfully']);
            } else {
                error_log("Failed to delete file: $filePath");
                sendJsonResponse(true, ['message' => 'API file marked as deleted but physical file not found']);
            }
        } else {
            error_log("Execute failed: " . $stmt->error);
            sendJsonResponse(false, [], 'Failed to delete API file: ' . $stmt->error, 500);
        }
        
        $stmt->close();
        $conn->close();

    } elseif ($uri === '/api/get-api-content' && $method === 'GET') {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            sendJsonResponse(false, [], 'Method not allowed', 405);
        }

        if (!isset($_GET['fileName'])) {
            sendJsonResponse(false, [], 'No filename provided', 400);
        }

        $conn = getDbConnection();
        $stmt = $conn->prepare("SELECT content, editable_lines, usecase FROM api_files WHERE file_name = ? AND is_active = 1");
        if (!$stmt) {
            error_log("Prepare failed: " . $conn->error);
            throw new Exception("Database prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param("s", $_GET['fileName']);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            // Update last accessed timestamp
            $updateStmt = $conn->prepare("UPDATE api_files SET last_accessed = CURRENT_TIMESTAMP WHERE file_name = ?");
            if (!$updateStmt) {
                error_log("Prepare failed for update: " . $conn->error);
                throw new Exception("Database prepare failed for update: " . $conn->error);
            }
            
            $updateStmt->bind_param("s", $_GET['fileName']);
            $updateStmt->execute();
            $updateStmt->close();

            sendJsonResponse(true, [
                'content' => $row['content'],
                'fileName' => $_GET['fileName'],
                'editableLines' => $row['editable_lines'],
                'usecase' => $row['usecase']
            ]);
        } else {
            sendJsonResponse(false, [], 'API file not found', 404);
        }
        
        $stmt->close();
        $conn->close();

    } elseif ($uri === '/api/get-api-by-id' && $method === 'POST') {
        try {
            $input = json_decode(file_get_contents('php://input'), true);
            if (!isset($input['id'])) {
                sendJsonResponse(false, [], 'No ID provided', 400);
            }

            $conn = getDbConnection();
            $stmt = $conn->prepare("SELECT id, file_name, content, editable_lines, usecase FROM api_files WHERE id = ? AND is_active = 1");
            if (!$stmt) {
                error_log("Prepare failed: " . $conn->error);
                throw new Exception("Database prepare failed: " . $conn->error);
            }
            
            $stmt->bind_param("i", $input['id']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($row = $result->fetch_assoc()) {
                // Update last accessed timestamp
                $updateStmt = $conn->prepare("UPDATE api_files SET last_accessed = CURRENT_TIMESTAMP WHERE id = ?");
                if (!$updateStmt) {
                    error_log("Prepare failed for update: " . $conn->error);
                    throw new Exception("Database prepare failed for update: " . $conn->error);
                }
                
                $updateStmt->bind_param("i", $input['id']);
                $updateStmt->execute();
                $updateStmt->close();

                sendJsonResponse(true, [
                    'id' => $row['id'],
                    'content' => $row['content'],
                    'fileName' => $row['file_name'],
                    'editableLines' => $row['editable_lines'],
                    'usecase' => $row['usecase']
                ]);
            } else {
                sendJsonResponse(false, [], 'API file not found', 404);
            }
            
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            error_log("Get API by ID error: " . $e->getMessage());
            sendJsonResponse(false, [], 'Error fetching API: ' . $e->getMessage(), 500);
        }

    } elseif ($uri === '/api/update-api' && $method === 'POST') {
        try {
            $input = json_decode(file_get_contents('php://input'), true);
            if (!isset($input['code']) || !isset($input['fileName'])) {
                sendJsonResponse(false, [], 'Missing required parameters', 400);
            }

            $fileName = $input['fileName'];
            $filePath = $DIRS['api'] . '/' . $fileName;
            $editableLines = isset($input['editableLines']) ? $input['editableLines'] : '';
            $usecase = isset($input['usecase']) ? $input['usecase'] : '';

            // Log the input data
            error_log("Update API request - File: $fileName, Editable Lines: $editableLines, Usecase: $usecase");

            // First, try to save the file
            if (file_put_contents($filePath, $input['code'])) {
                // File saved successfully, now try database operations
                try {
                    $conn = getDbConnection();
                    
                    // First check if the file exists in the database
                    $checkStmt = $conn->prepare("SELECT id FROM api_files WHERE file_name = ? AND is_active = 1");
                    if (!$checkStmt) {
                        error_log("Check prepare failed: " . $conn->error);
                        sendJsonResponse(false, [], 'Database prepare failed: ' . $conn->error, 500);
                    }
                    
                    $checkStmt->bind_param("s", $fileName);
                    $checkStmt->execute();
                    $result = $checkStmt->get_result();
                    
                    if ($result->num_rows === 0) {
                        // File doesn't exist in database, insert it
                        $insertStmt = $conn->prepare("INSERT INTO api_files (file_name, file_path, content, editable_lines, usecase) VALUES (?, ?, ?, ?, ?)");
                        if (!$insertStmt) {
                            error_log("Insert prepare failed: " . $conn->error);
                            sendJsonResponse(false, [], 'Database prepare failed: ' . $conn->error, 500);
                        }
                        
                        $insertStmt->bind_param("sssss", $fileName, $filePath, $input['code'], $editableLines, $usecase);
                        
                        if ($insertStmt->execute()) {
                            sendJsonResponse(true, [
                                'fileName' => $fileName,
                                'message' => 'API created successfully'
                            ]);
                        } else {
                            error_log("Insert execute failed: " . $insertStmt->error);
                            sendJsonResponse(false, [], 'Failed to create API: ' . $insertStmt->error, 500);
                        }
                        $insertStmt->close();
                    } else {
                        // File exists, update it
                        $updateStmt = $conn->prepare("UPDATE api_files SET content = ?, editable_lines = ?, usecase = ?, updated_at = CURRENT_TIMESTAMP WHERE file_name = ? AND is_active = 1");
                        if (!$updateStmt) {
                            error_log("Update prepare failed: " . $conn->error);
                            sendJsonResponse(false, [], 'Database prepare failed: ' . $conn->error, 500);
                        }
                        
                        $updateStmt->bind_param("ssss", $input['code'], $editableLines, $usecase, $fileName);
                        
                        if ($updateStmt->execute()) {
                            if ($updateStmt->affected_rows > 0) {
                                sendJsonResponse(true, [
                                    'fileName' => $fileName,
                                    'message' => 'API updated successfully'
                                ]);
                            } else {
                                error_log("No rows affected in update for file: $fileName");
                                sendJsonResponse(false, [], 'No changes were made to the API', 400);
                            }
                        } else {
                            error_log("Update execute failed: " . $updateStmt->error);
                            sendJsonResponse(false, [], 'Failed to update API: ' . $updateStmt->error, 500);
                        }
                        $updateStmt->close();
                    }
                    
                    $checkStmt->close();
                    $conn->close();
                } catch (Exception $dbError) {
                    error_log("Database error: " . $dbError->getMessage());
                    sendJsonResponse(false, [], 'Database error: ' . $dbError->getMessage(), 500);
                }
            } else {
                error_log("Failed to write file: $filePath");
                sendJsonResponse(false, [], 'Failed to update API file', 500);
            }
        } catch (Exception $e) {
            error_log("Update API error: " . $e->getMessage());
            sendJsonResponse(false, [], 'Error updating API: ' . $e->getMessage(), 500);
        }

    } elseif ($uri === '/api/update-api-settings' && $method === 'POST') {
        try {
            $input = json_decode(file_get_contents('php://input'), true);
            if (!isset($input['fileName']) || !isset($input['editableLines'])) {
                sendJsonResponse(false, [], 'Missing required parameters', 400);
            }

            $conn = getDbConnection();
            $stmt = $conn->prepare("UPDATE api_files SET editable_lines = ?, updated_at = CURRENT_TIMESTAMP WHERE file_name = ? AND is_active = 1");
            if (!$stmt) {
                error_log("Prepare failed: " . $conn->error);
                sendJsonResponse(false, [], 'Database prepare failed: ' . $conn->error, 500);
            }
            
            $stmt->bind_param("ss", $input['editableLines'], $input['fileName']);
            
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    sendJsonResponse(true, [
                        'message' => 'API settings updated successfully'
                    ]);
                } else {
                    sendJsonResponse(false, [], 'No changes were made to the API settings', 400);
                }
            } else {
                error_log("Execute failed: " . $stmt->error);
                sendJsonResponse(false, [], 'Failed to update API settings: ' . $stmt->error, 500);
            }
            
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            error_log("Update API settings error: " . $e->getMessage());
            sendJsonResponse(false, [], 'Error updating API settings: ' . $e->getMessage(), 500);
        }

    } elseif ($uri === '/api/health') {
        try {
            $conn = getDbConnection();
            $conn->close();
            sendJsonResponse(true, ['status' => 'Server and database are running']);
        } catch (Exception $e) {
            sendJsonResponse(false, [], 'Server is running but database connection failed: ' . $e->getMessage(), 500);
        }
    } else {
        sendJsonResponse(false, [], 'Endpoint not found', 404);
    }
} catch (Exception $e) {
    error_log("Server error: " . $e->getMessage());
    sendJsonResponse(false, [], 'Server error: ' . $e->getMessage(), 500);
}

// Helper function to send JSON response
function sendJsonResponse($success, $data = [], $error = null, $statusCode = 200) {
    ob_clean(); // Clear any previous output
    http_response_code($statusCode);
    echo json_encode([
        'success' => $success,
        'data' => $data,
        'error' => $error
    ]);
    exit();
}
