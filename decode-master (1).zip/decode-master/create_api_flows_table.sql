-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS flow_db;
USE flow_db;

-- Create api_flows table
CREATE TABLE IF NOT EXISTS api_flows (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    flow_data JSON NOT NULL,
    node_configs JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'Draft',
    version VARCHAR(50),
    clone_remark TEXT,
    secondary_forms JSON,
    information_form JSON
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add indexes for better performance
CREATE INDEX idx_api_flows_name ON api_flows(name);
CREATE INDEX idx_api_flows_status ON api_flows(status);
CREATE INDEX idx_api_flows_created_at ON api_flows(created_at);

-- Add some sample data (optional)
INSERT INTO api_flows (name, flow_data, status, version) VALUES 
('Sample API Flow 1', '{"nodes":[],"edges":[]}', 'Draft', '1.0'),
('Sample API Flow 2', '{"nodes":[],"edges":[]}', 'Accepted', '1.0'); 