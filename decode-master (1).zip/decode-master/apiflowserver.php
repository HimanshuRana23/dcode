<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database configuration
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'flow_db';

// Create connection
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    die(json_encode(['error' => 'Connection failed: ' . $conn->connect_error]));
}

// Create api_flows table if it doesn't exist
$createTableQuery = "CREATE TABLE IF NOT EXISTS api_flows (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    flow_data JSON NOT NULL,
    node_configs JSON,
    status VARCHAR(255),
    version VARCHAR(255),
    clone_remark VARCHAR(255),
    secondary_forms JSON,
    information_form JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if (!$conn->query($createTableQuery)) {
    http_response_code(500);
    die(json_encode(['error' => 'Error creating table: ' . $conn->error]));
}

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Handle GET request (fetch flow)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['id'])) {
        $id = $conn->real_escape_string($_GET['id']);
        
        $query = "SELECT * FROM api_flows WHERE id = '$id'";
        $result = $conn->query($query);
        
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $flow = json_decode($row['flow_data'], true);
            $nodeConfigs = json_decode($row['node_configs'], true) ?? [];
            
            // Merge node configurations with flow data
            if (isset($flow['nodes'])) {
                foreach ($flow['nodes'] as &$node) {
                    if (isset($nodeConfigs[$node['id']])) {
                        $node['data']['config'] = $nodeConfigs[$node['id']];
                    }
                }
            }
            
            echo json_encode([
                'name' => $row['name'],
                'flow' => $flow,
                'status' => $row['status'],
                'version' => $row['version'],
                'clone_remark' => $row['clone_remark'],
                'secondary_forms' => json_decode($row['secondary_forms'], true),
                'information_form' => json_decode($row['information_form'], true)
            ]);
        } else {
            echo json_encode(['error' => 'Flow not found']);
        }
    } else {
        // List all API flows
        $query = "SELECT id, name, status, version, clone_remark, created_at FROM api_flows ORDER BY created_at DESC";
        $result = $conn->query($query);
        
        $flows = [];
        while ($row = $result->fetch_assoc()) {
            $flows[] = $row;
        }
        
        echo json_encode($flows);
    }
}

// Handle POST request (save flow)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data) {
        echo json_encode(['error' => 'Invalid JSON data']);
        exit();
    }
    
    $name = $conn->real_escape_string($data['name']);
    $flowData = $conn->real_escape_string(json_encode($data['flow'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    $status = isset($data['status']) ? $conn->real_escape_string($data['status']) : 'Draft';
    $version = isset($data['version']) ? $conn->real_escape_string($data['version']) : '1.0';
    $cloneRemark = isset($data['clone_remark']) ? $conn->real_escape_string($data['clone_remark']) : null;
    $secondaryForms = isset($data['secondary_forms']) ? $conn->real_escape_string(json_encode($data['secondary_forms'])) : null;
    $informationForm = isset($data['information_form']) ? $conn->real_escape_string(json_encode($data['information_form'])) : null;
    
    // Extract node configurations
    $nodeConfigs = [];
    if (isset($data['flow']['nodes'])) {
        foreach ($data['flow']['nodes'] as $node) {
            if (isset($node['data']['config'])) {
                $nodeConfigs[$node['id']] = $node['data']['config'];
            }
        }
    }
    $nodeConfigsJson = $conn->real_escape_string(json_encode($nodeConfigs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    
    if (isset($data['id']) && $data['id'] !== 'new') {
        // Update existing flow
        $id = $conn->real_escape_string($data['id']);
        $query = "UPDATE api_flows SET 
                  name = '$name', 
                  flow_data = '$flowData',
                  node_configs = '$nodeConfigsJson',
                  status = '$status',
                  version = '$version',
                  clone_remark = " . ($cloneRemark ? "'$cloneRemark'" : "NULL") . ",
                  secondary_forms = " . ($secondaryForms ? "'$secondaryForms'" : "NULL") . ",
                  information_form = " . ($informationForm ? "'$informationForm'" : "NULL") . ",
                  updated_at = NOW() 
                  WHERE id = '$id'";
                  
        if ($conn->query($query)) {
            echo json_encode(['success' => true, 'id' => $id]);
        } else {
            echo json_encode(['error' => 'Error updating flow: ' . $conn->error]);
        }
    } else {
        // Create new flow
        $query = "INSERT INTO api_flows (
                    name, 
                    flow_data, 
                    node_configs, 
                    status,
                    version,
                    clone_remark,
                    secondary_forms,
                    information_form,
                    created_at, 
                    updated_at
                  ) VALUES (
                    '$name', 
                    '$flowData', 
                    '$nodeConfigsJson',
                    '$status',
                    '$version',
                    " . ($cloneRemark ? "'$cloneRemark'" : "NULL") . ",
                    " . ($secondaryForms ? "'$secondaryForms'" : "NULL") . ",
                    " . ($informationForm ? "'$informationForm'" : "NULL") . ",
                    NOW(), 
                    NOW()
                  )";
                  
        if ($conn->query($query)) {
            echo json_encode(['success' => true, 'id' => $conn->insert_id]);
        } else {
            echo json_encode(['error' => 'Error creating flow: ' . $conn->error]);
        }
    }
}

$conn->close();
?> 