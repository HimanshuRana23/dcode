<?php
// Generate a random integer between 1 and 100
$randomNumber = rand(1, 100);

// Output the number
echo "Random number: " . $randomNumber;
?>