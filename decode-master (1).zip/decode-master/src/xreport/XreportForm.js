import React, { useState } from "react";
import Select from 'react-select';
import 'bootstrap/dist/css/bootstrap.min.css';
import './XreportForm.css';

export default function XreportForm({ onSubmit, onReset }) {
  const [formValue, setFormValue] = useState({
    server: "",
    table: "",
    columns: [],
    filters: [{ type: "", value: "" }]
  });

  const [errors, setErrors] = useState({});
  const [isFormChanged, setIsFormChanged] = useState(false);

  const validateForm = () => {
    const newErrors = {};
    
    if (!formValue.server) {
      newErrors.server = "Server is required";
    }
    if (!formValue.table) {
      newErrors.table = "Table is required";
    }
    if (!formValue.columns.length) {
      newErrors.columns = "At least one column must be selected";
    }

    // Check if any filter has both type and value
    const hasValidFilter = formValue.filters.some(filter => filter.type && filter.value);
    if (!hasValidFilter) {
      newErrors.filters = "At least one filter must be specified";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (selectedOption, { name }) => {
    setIsFormChanged(true);
    setFormValue({
      ...formValue,
      [name]: selectedOption ? selectedOption.value : ""
    });
  };

  const handleMultiChange = (selectedOptions) => {
    setIsFormChanged(true);
    setFormValue({
      ...formValue,
      columns: selectedOptions ? selectedOptions.map(option => option.value) : []
    });
  };

  const handleFilterChange = (index, field, value) => {
    setIsFormChanged(true);
    const newFilters = [...formValue.filters];
    newFilters[index] = {
      ...newFilters[index],
      [field]: value
    };
    setFormValue({
      ...formValue,
      filters: newFilters
    });
  };

  const removeFilterGroup = (index) => {
    setIsFormChanged(true);
    const newFilters = formValue.filters.filter((_, i) => i !== index);
    setFormValue({
      ...formValue,
      filters: newFilters.length ? newFilters : [{ type: "", value: "" }]
    });
  };

  const addFilterGroup = () => {
    setIsFormChanged(true);
    setFormValue({
      ...formValue,
      filters: [...formValue.filters, { type: "", value: "" }]
    });
  };

  const handleSubmit = e => {
    e.preventDefault();
    
    if (!isFormChanged) {
      alert("No changes have been made to the form. Please make changes before submitting.");
      return;
    }

    if (!validateForm()) {
      return;
    }

    onSubmit(formValue);
    setIsFormChanged(false);
  };

  const resetForm = () => {
    setFormValue({
      server: "",
      table: "",
      columns: [],
      filters: [{ type: "", value: "" }]
    });
    setIsFormChanged(false);
    setErrors({});
    onReset && onReset();
  };

  const customStyles = {
    control: (base) => ({
      ...base,
      minHeight: '32px',
      height: '32px',
      fontSize: '0.875rem'
    }),
    option: (base) => ({
      ...base,
      fontSize: '0.875rem',
      padding: '8px 12px'
    }),
    menu: (base) => ({
      ...base,
      fontSize: '0.875rem'
    }),
    multiValue: (base) => ({
      ...base,
      fontSize: '0.875rem'
    })
  };

  const serverOptions = [
    { value: 'staging', label: 'Staging' },
    { value: 'production', label: 'Production' },
    { value: 'development', label: 'Development' },
    { value: 'testing', label: 'Testing' }
  ];

  const tableOptions = [
    { value: 'modules', label: 'Module' },
    { value: 'users', label: 'User' },
    { value: 'locations', label: 'Location' }
  ];

  const columnOptions = [
    { value: 'module_id', label: 'ModuleID' },
    { value: 'module_name', label: 'ModuleName' }
  ];

  const filterTypeOptions = [
    { value: 'company_id', label: 'Company ID' },
    { value: 'module_id', label: 'Module ID' },
    { value: 'startsWith', label: 'Starts With' },
    { value: 'endsWith', label: 'Ends With' }
  ];

  return (
    <div className="form-container bg-white">
      <form onSubmit={handleSubmit} className="needs-validation" noValidate>
        <div className="row">
          <div className="col-md-6">
            <div className="form-group mb-3">
              <label htmlFor="validationDefault01" className="form-label">Server</label>
              <Select
                name="server"
                value={serverOptions.find(option => option.value === formValue.server) || null}
                onChange={handleChange}
                options={serverOptions}
                styles={customStyles}
                placeholder="Select Server"
                isSearchable
                isClearable
                required
              />
              {errors.server && <div className="text-danger small mt-1">{errors.server}</div>}
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group mb-3">
              <label htmlFor="validationDefault02" className="form-label">Table</label>
              <Select
                name="table"
                value={tableOptions.find(option => option.value === formValue.table) || null}
                onChange={handleChange}
                options={tableOptions}
                styles={customStyles}
                placeholder="Select Table"
                isSearchable
                isClearable
                required
              />
              {errors.table && <div className="text-danger small mt-1">{errors.table}</div>}
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-md-6">
            <div className="form-group mb-3">
              <label htmlFor="validationDefault03" className="form-label">Columns</label>
              <Select
                name="columns"
                value={columnOptions.filter(option => formValue.columns.includes(option.value)) || []}
                onChange={handleMultiChange}
                options={columnOptions}
                styles={customStyles}
                placeholder="Select Columns"
                isMulti
                isSearchable
                isClearable
                required
              />
              {errors.columns && <div className="text-danger small mt-1">{errors.columns}</div>}
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-12">
            <label className="form-label">Filters</label>
            {errors.filters && <div className="text-danger small mb-2">{errors.filters}</div>}
            {formValue.filters.map((filter, index) => (
              <div key={index} className="row mb-3">
                <div className="col-md-5">
                  <Select
                    name={`filterType-${index}`}
                    value={filterTypeOptions.find(option => option.value === filter.type) || null}
                    onChange={(selectedOption) => handleFilterChange(index, 'type', selectedOption?.value)}
                    options={filterTypeOptions}
                    styles={customStyles}
                    placeholder="Select Filter Type"
                    isSearchable
                    isClearable
                  />
                </div>
                <div className="col-md-5">
                  <input
                    type="text"
                    className="form-control form-control-sm"
                    value={filter.value}
                    onChange={(e) => handleFilterChange(index, 'value', e.target.value)}
                    placeholder="Enter filter value"
                  />
                </div>
                <div className="col-md-2">
                  {index === formValue.filters.length - 1 && (
                    <button
                      type="button"
                      className="btn btn-outline-primary btn-sm"
                      onClick={addFilterGroup}
                    >
                      +
                    </button>
                  )}
                  {formValue.filters.length > 1 && (
                    <button
                      type="button"
                      className="btn btn-outline-danger btn-sm ms-2"
                      onClick={() => removeFilterGroup(index)}
                    >
                      -
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="row mt-4">
          <div className="col-md-6">
            <div className="form-group">
              <button className="btn btn-primary px-4" type="submit">
                Submit
              </button>
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group d-flex justify-content-end">
              <button 
                type="button" 
                className="btn btn-outline-secondary px-4" 
                onClick={resetForm}
              >
                Reset
              </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
