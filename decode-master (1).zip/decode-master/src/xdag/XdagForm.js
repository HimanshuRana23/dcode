import React, { useState } from "react";
import Select from 'react-select';
import 'bootstrap/dist/css/bootstrap.min.css';
import './XdagForm.css';

export default function XdagForm({ onSubmit, onReset }) {
  // State for DAG
  const [dag, setDag] = useState("");
  // State for parameter values (object: {paramName: value})
  const [paramValues, setParamValues] = useState({});
  const [errors, setErrors] = useState({});
  const [isFormChanged, setIsFormChanged] = useState(false);

  // Options
  const dagOptions = [
    { value: '1', label: 'Submission Email for a Single Next Form Assigned to One or More Users', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_submission_mail/dagRuns' },
    { value: '2', label: 'Trigger the Next Form for Specific Users Based on a Question ID in the Current Form', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_user_api/dagRuns' },
    { value: '3', label: 'Form scheduled based on condition, with schedule derived from Main Form inputs.', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_schedule_form/dagRuns' },
    { value: '4', label: 'Workflow status change based on form submission', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_workflow_approval_status/dagRuns' },
    { value: '5', label: 'Excel Upload in a form and Submission in a form', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_excel_upload/dagRuns' },
    { value: '6', label: 'Excel Upload in a IOT module and Submission in a form', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_excel_upload_in_iot_module/dagRuns' },
    { value: '7', label: 'Excel Upload', url: 'https://airflowprod.dfos.co:8080/api/v1/dags' },
    { value: '8', label: 'Form Submission based on some condition ', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_form_submission/dagRuns' },
    { value: '9', label: 'Task Reaudit i.e. NC Rejected then retriggering the NC  (Fire and Safety)', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_NC_retrigger_when_rejected/dagRuns' },
    { value: '10', label: 'Submission Email for Multiple Next Forms Assigned to One or More Users', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_api_submission_mail_for_multiple_forms/dagRuns' },
    { value: '11', label: 'Sending Submission mail from the master form (Fire and Safety)', url: 'https://airflowprod.dfos.co:8080/api/v1/dags' },
    { value: '12', label: 'Trigger The Next Form for Specific Users Based on a The Conditions', url: 'https://airflowprod.dfos.co:8080/api/v1/dags' },
    { value: '13', label: 'Scheduling a form based on the master form entries  (Fire and Safety)', url: 'https://airflowprod.dfos.co:8080/api/v1/dags' },
    { value: '14', label: 'Answer update based on a condition', url: 'https://airflowprod.dfos.co:8080/api/v1/dags' },
    { value: '15', label: 'Form status close or open based on a condition', url: 'https://airflowprod.dfos.co:8080/api/v1/dags' },
    { value: '16', label: 'REMINDER MAILS', url: '' },
  ];

  // Parameter names per DAG type
  const dagParams = {
    '1': [
      { name: 'field_id', label: 'Question ID', placeholder: 'Put all the questions in comma seperated format (e.g. 12,45,33)'},
      { name: 'attachment_field_id', label: 'Attachment Field ID', placeholder: 'Put all the questions in comma seperated format (e.g. 12,45,33)'},
      { name: 'attachment_field_image_id', label: 'Attachment Field Image ID', placeholder: 'Put all the questions in comma seperated format (e.g. 12,45,33)'},
      { name: 'form_name', label: 'Form Name', placeholder: 'Form Name' }
    ],
    '2': [
      { name: 'condition', label: 'Condition', placeholder: 'Enter the Condition which Bot needs to check'},
      { name: 'value', label: 'Value', placeholder: 'Value from which the condition will be compared' },
      { name: 'field_id', label: 'Field ID', placeholder: 'Question ID from where the user needs to be fetched' },
      { name: 'condition_var', label: 'Condition variable', placeholder: 'Condition Variable which needs to be passed in the condition' },
    ],
    '3': [
      { name: 'module_field_id', label: 'Module Question ID', placeholder: 'Question ID from which the Module will be fetched'},
      { name: 'module_id', label: 'Static Module ID', placeholder: 'Static Module ID'},
      { name: 'form_field_id', label: 'Form Question ID', placeholder: 'Question ID from which the Form  will be fetched'},
      { name: 'form_id', label: 'Statuc Form ID', placeholder: 'Static Form ID'},
      { name: 'schedule_field_users', label: 'Schedule User Question ID', placeholder: 'Question ID from which the Scheduled User  will be fetched'},
      { name: 'schedule_static_users', label: 'Static Schedule Users', placeholder: 'Put the user ID who will fill the scheduled Form'},
      { name: 'bot_user_id', label: 'Bot User ID', placeholder: 'Make sure the Bot has been logged in on DFOS once' },
      { name: 'start_date_field_id', label: 'Start Date Question ID', placeholder: 'Question ID from which the Start Date will be fetched'},
      { name: 'start_date', label: 'Static Start Date', placeholder: 'Static Start Date (year-month-days)'},
      { name: 'end_date_field_id', label: 'End Date Question ID', placeholder: 'Question ID from which the End Date will be fetched'},
      { name: 'end_date', label: 'Static End Date', placeholder: 'End Date will be number (no. of Days from the start date) '},
      { name: 'approver_field_id', label: 'Approver Question ID', placeholder: 'Question ID from which the Approved or Not  will be fetched'},
    ],
    '4': [
      { name: 'workflow_status', label: 'Workflow Status', placeholder: 'Workflow Status'},
    ],
    '5': [
      { name: 'submission_form_id', label: 'Submission Form ID', placeholder: 'Submission Form ID'},
      { name: 'bot_user_id', label: 'Bot User ID', placeholder: 'Make sure the Bot has been logged in on DFOS once' },
    ],
    '6': [
      { name: 'submission_form_id', label: 'Submission Form ID', placeholder: 'Submission Form ID'},
      { name: 'bot_user_id', label: 'Bot User ID', placeholder: 'Make sure the Bot has been logged in on DFOS once' },
    ],
    '8': [
      { name: 'field_id', label: 'Question ID', placeholder: 'Question ID from where we will check if its approved or rejected'},
      { name: 'bot_user_id', label: 'Bot User ID', placeholder: 'Make sure the Bot has been logged in on DFOS once' },
    ],
    '10': [
      { name: 'field_id', label: 'Question ID', placeholder: 'Put all the questions in comma seperated format (e.g. 12,45,33)'},
      { name: 'attachment_field_id', label: 'Attachment Field ID', placeholder: 'Put all the questions in comma seperated format (e.g. 12,45,33)'},
      { name: 'attachment_field_image_id', label: 'Attachment Field Image ID', placeholder: 'Put all the questions in comma seperated format (e.g. 12,45,33)'},
      { name: 'form_name', label: 'Form Name', placeholder: 'Form Name' }
    ],
    // You can add more for other dag values if needed
  };

  // Validation
  const validateForm = () => {
    const newErrors = {};
    if (!dag) newErrors.dag = "DAG is required";
    (dagParams[dag] || []).forEach(param => {
      if (!paramValues[param.name]) newErrors[param.name] = "Value is required";
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handlers
  const handleDagChange = (selectedOption) => {
    setIsFormChanged(true);
    setDag(selectedOption ? selectedOption.value : "");
    // Reset parameter values when DAG changes
    const newParamValues = {};
    (dagParams[selectedOption ? selectedOption.value : ""] || []).forEach(param => {
      newParamValues[param.name] = "";
    });
    setParamValues(newParamValues);
    // Notify parent component about DAG change
    onReset && onReset();
  };

  const handleParamValueChange = (paramName, value) => {
    setIsFormChanged(true);
    setParamValues(prev => ({ ...prev, [paramName]: value }));
  };

  const handleSubmit = e => {
    e.preventDefault();
    if (!isFormChanged) {
      alert("No changes have been made to the form. Please make changes before submitting.");
      return;
    }
    if (!validateForm()) return;
    
    // Create parameters object with the form values
    const parameters = {};
    Object.entries(paramValues).forEach(([key, value]) => {
      if (value) {
        parameters[key] = value;
      }
    });
    
    onSubmit({ dag, parameters });
    setIsFormChanged(false);
  };

  const resetForm = () => {
    setDag("");
    setParamValues({});
    setIsFormChanged(false);
    setErrors({});
    onReset && onReset();
  };

  const customStyles = {
    control: (base) => ({ ...base, minHeight: '32px', height: '32px', fontSize: '0.875rem' }),
    option: (base, state) => {
      const value = state.data?.value;
      const isHighlighted = ['1','2','3', '4','5','6', '8','10'].includes(value);
      return {
        ...base,
        fontSize: '0.875rem',
        padding: '8px 12px',
        backgroundColor: isHighlighted ? '#e8f5e9' : (base.backgroundColor || '#ffffff'),
        color: isHighlighted ? '#2e7d32' : (base.color || '#000000'),
        '&:hover': {
          backgroundColor: isHighlighted ? '#c8e6c9' : (base['&:hover']?.backgroundColor || '#f5f5f5')
        }
      };
    },
    menu: (base) => ({ ...base, fontSize: '0.875rem' }),
    multiValue: (base) => ({ ...base, fontSize: '0.875rem' })
  };

  const paramsToShow = dagParams[dag] || [];

  return (
    <div className="form-container bg-white">
      <form onSubmit={handleSubmit} className="needs-validation" noValidate>
        {/* DAG Dropdown */}
        <div className="mb-4">
          <label className="form-label">DAG Type</label>
          <Select
            name="dag"
            value={dagOptions.find(option => option.value === dag) || null}
            onChange={handleDagChange}
            options={dagOptions}
            styles={customStyles}
            placeholder="Select DAG Type"
            isSearchable
            isClearable
            required
          />
          {errors.dag && <div className="text-danger small mt-1">{errors.dag}</div>}
        </div>
        {/* Parameters Section */}
        {paramsToShow.length > 0 && (
          <div className="mb-4">
            {paramsToShow.map(param => (
              <div className="row mb-2" key={param.name}>
                <div className="col-md-5 d-flex align-items-center">
                  <label className="form-label mb-0">{param.label}</label>
                </div>
                <div className="col-md-7">
                  <input
                    type="text"
                    className="form-control"
                    value={paramValues[param.name] || ""}
                    onChange={e => handleParamValueChange(param.name, e.target.value)}
                    placeholder={`Enter ${param.placeholder}`}
                    required
                  />
                  {errors[param.name] && <div className="text-danger small mt-1">{errors[param.name]}</div>}
                </div>
              </div>
            ))}
          </div>
        )}
        {/* Submit/Reset */}
        <div className="row mt-4">
          <div className="col-md-6">
            <div className="form-group">
              <button className="btn btn-primary px-4" type="submit">
                Submit
              </button>
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group d-flex justify-content-end">
              <button 
                type="button" 
                className="btn btn-outline-secondary px-4" 
                onClick={resetForm}
              >
                Reset
              </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
