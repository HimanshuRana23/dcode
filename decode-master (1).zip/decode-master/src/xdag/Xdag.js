import React, { useState } from "react";
import XdagForm from "./XdagForm";

const dagOptions = [
    { value: '1', label: 'Submission Email for a Single Next Form Assigned to One or More Users', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_submission_mail/dagRuns' },
    { value: '2', label: 'Trigger the Next Form for Specific Users Based on a Question ID in the Current Form', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_user_api/dagRuns' },
    { value: '3', label: 'Form scheduled based on condition, with schedule derived from Main Form inputs.', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_schedule_form/dagRuns' },
    { value: '4', label: 'Workflow status change based on a condition', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_workflow_approval_status/dagRuns' },
    { value: '5', label: 'Excel Upload in a form and Submission in a form', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_excel_upload/dagRuns' },
    { value: '6', label: 'Excel Upload in a IOT module and Submission in a form', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_excel_upload_in_iot_module/dagRuns' },
    { value: '7', label: 'Excel Upload', url: '' },
    { value: '8', label: 'Form Submission based on some condition ', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_form_submission/dagRuns' },
    { value: '9', label: 'Task Reaudit i.e. NC Rejected then retriggering the NC  (Fire and Safety)', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_NC_retrigger_when_rejected/dagRuns' },
    { value: '10', label: 'Submission Email for Multiple Next Forms Assigned to One or More Users', url: 'https://airflowprod.dfos.co:8080/api/v1/dags/CompanyName_ProjectName_GlobalStandardBot_api_submission_mail_for_multiple_forms/dagRuns' },
    { value: '11', label: 'Sending Submission mail from the master form (Fire and Safety)', url: '' },
    { value: '12', label: 'Trigger The Next Form for Specific Users Based on a The Conditions', url: '' },
    { value: '13', label: 'Scheduling a form based on the master form entries  (Fire and Safety)', url: '' },
    { value: '14', label: 'Answer update based on a condition', url: '' },
    { value: '15', label: 'Form status close or open based on a condition', url: '' },
    { value: '16', label: 'REMINDER MAILS', url: '' },
];

const Xdag = () => {
    const [output, setOutput] = useState("");
    const [dagType, setDagType] = useState("");
    const [copySuccess, setCopySuccess] = useState("");
    const [dagTypeCopySuccess, setDagTypeCopySuccess] = useState("");

    const handleSubmit = submission => {
        // submission: { url, dag, parameters }
        const selectedDag = dagOptions.find(opt => opt.value === submission.dag);
        setDagType(submission.dag);
        setOutput(JSON.stringify(submission.parameters, null, 2));
    };

    const handleReset = () => {
        setOutput("");
        setDagType("");
        setCopySuccess("");
        setDagTypeCopySuccess("");
    };

    const handleCopy = () => {
        navigator.clipboard.writeText(output);
        setCopySuccess("Copied!");
        setTimeout(() => setCopySuccess(""), 2000);
    };

    const handleDagTypeCopy = () => {
        const dagUrl = dagOptions.find(opt => opt.value === dagType)?.url || 'No URL found';
        navigator.clipboard.writeText(dagUrl);
        setDagTypeCopySuccess("Copied!");
        setTimeout(() => setDagTypeCopySuccess(""), 2000);
    };

    return (
        <div className="container px-5">
            <h3 className="text-left mb-4 pt-4">Data Access-Point Generation</h3>
            <XdagForm onSubmit={handleSubmit} onReset={handleReset} />
            <div 
                className="my-4" 
                style={{
                    height: '1px',
                    background: 'linear-gradient(to right, transparent, #dee2e6, transparent)'
                }}
            />
            <div>
                <h3 className="mb-3">Output:</h3>
                {output && (
                    <>
                        <div className="mb-4">
                            <h4 className="mb-2">DAG Type:</h4>
                            <div className="position-relative">
                                <pre
                                    className="mt-2 p-4"
                                    style={{ backgroundColor: "rgb(230, 230, 230)" }}
                                >
                                    <code>{dagOptions.find(opt => opt.value === dagType)?.url || 'No URL found'}</code>
                                </pre>
                                <div className="position-absolute top-0 end-0 p-2">
                                    <button 
                                        className="btn btn-sm btn-outline-primary"
                                        onClick={handleDagTypeCopy}
                                    >
                                        {dagTypeCopySuccess || "Copy"}
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div>
                            <h4 className="mb-2">Config JSON:</h4>
                            <div className="position-relative">
                                <pre
                                    className="mt-2 p-4"
                                    style={{ backgroundColor: "rgb(230, 230, 230)" }}
                                >
                                    <code>{output}</code>
                                </pre>
                                <div className="position-absolute top-0 end-0 p-2">
                                    <button 
                                        className="btn btn-sm btn-outline-primary"
                                        onClick={handleCopy}
                                    >
                                        {copySuccess || "Copy"}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};

export default Xdag;