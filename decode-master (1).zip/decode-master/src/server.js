const express = require('express');
const cors = require('cors');
const fs = require('fs').promises;
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

// Paths to store form submissions for different forms
const FORMS_DIR = path.join(__dirname, 'data', 'forms');
const FORMDRILLDOWN_DIR = path.join(__dirname, 'data', 'formdrilldown');
const FORM2_DIR = path.join(__dirname, 'data', 'form2');
const API_DIR = path.join(__dirname, 'data', 'api');

// Ensure the forms directories exist
const ensureFormsDirectory = async (dirPath) => {
  try {
    await fs.access(dirPath);
  } catch (error) {
    await fs.mkdir(dirPath, { recursive: true });
  }
};

// Initialize all form directories
const initializeFormDirectories = async () => {
  await ensureFormsDirectory(FORMS_DIR);
  await ensureFormsDirectory(FORMDRILLDOWN_DIR);
  await ensureFormsDirectory(FORM2_DIR);
  await ensureFormsDirectory(API_DIR);
};

// Generate a unique filename based on timestamp
const generateFileName = () => {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  return `form_${timestamp}.json`;
};

// Save regular form submission
app.post('/api/save-form', async (req, res) => {
  try {
    console.log('Received regular form submission request:', req.body);
    
    // Ensure the forms directory exists
    await ensureFormsDirectory(FORMS_DIR);

    // Generate a unique ID and timestamp
    const submission = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      ...req.body
    };

    // Generate filename
    const fileName = generateFileName();
    const filePath = path.join(FORMS_DIR, fileName);

    // Save to file
    await fs.writeFile(filePath, JSON.stringify(submission, null, 2));
    console.log('Successfully saved regular form submission:', fileName);

    res.status(200).json({
      success: true,
      message: 'Form data saved successfully',
      fileName,
      submissionId: submission.id
    });
  } catch (error) {
    console.error('Error saving regular form submission:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to save form submission',
      details: error.message 
    });
  }
});

// Save form drilldown submission
app.post('/api/save-drilldown', async (req, res) => {
  try {
    console.log('Received form drilldown submission request:', req.body);
    
    // Ensure the form drilldown directory exists
    await ensureFormsDirectory(FORMDRILLDOWN_DIR);

    // Generate a unique ID and timestamp
    const submission = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      ...req.body
    };

    // Generate filename
    const fileName = generateFileName();
    const filePath = path.join(FORMDRILLDOWN_DIR, fileName);

    // Save to file
    await fs.writeFile(filePath, JSON.stringify(submission, null, 2));
    console.log('Successfully saved form drilldown submission:', fileName);

    res.status(200).json({
      success: true,
      message: 'Form drilldown data saved successfully',
      fileName,
      submissionId: submission.id
    });
  } catch (error) {
    console.error('Error saving form drilldown submission:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to save form drilldown submission',
      details: error.message 
    });
  }
});

// Get all saved form drilldown submissions
app.get('/api/drilldown-forms', async (req, res) => {
  try {
    await ensureFormsDirectory(FORMDRILLDOWN_DIR);
    const files = await fs.readdir(FORMDRILLDOWN_DIR);
    
    const forms = await Promise.all(
      files.map(async (file) => {
        const content = await fs.readFile(path.join(FORMDRILLDOWN_DIR, file), 'utf8');
        return JSON.parse(content);
      })
    );

    res.status(200).json({ success: true, forms });
  } catch (error) {
    console.error('Error fetching form drilldown submissions:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to fetch form drilldown submissions',
      details: error.message 
    });
  }
});

// Get all saved regular form submissions
app.get('/api/regular-forms', async (req, res) => {
  try {
    await ensureFormsDirectory(FORMS_DIR);
    const files = await fs.readdir(FORMS_DIR);
    
    const forms = await Promise.all(
      files.map(async (file) => {
        const content = await fs.readFile(path.join(FORMS_DIR, file), 'utf8');
        return JSON.parse(content);
      })
    );

    res.status(200).json({ success: true, forms });
  } catch (error) {
    console.error('Error fetching regular form submissions:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to fetch regular form submissions',
      details: error.message 
    });
  }
});

// Save API code
app.post('/api/save-api', async (req, res) => {
  try {
    console.log('Received API save request');
    
    // Ensure the API directory exists
    await ensureFormsDirectory(API_DIR);

    // Generate filename with epoch timestamp
    const timestamp = Date.now();
    const fileName = `api_${timestamp}.php`;
    const filePath = path.join(API_DIR, fileName);

    // Save the code to file
    await fs.writeFile(filePath, req.body.code);
    console.log('Successfully saved API file:', fileName);

    res.status(200).json({
      success: true,
      message: 'API code saved successfully',
      fileName
    });
  } catch (error) {
    console.error('Error saving API code:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to save API code',
      details: error.message 
    });
  }
});

// List all API files
app.get('/api/list-apis', async (req, res) => {
  try {
    await ensureFormsDirectory(API_DIR);
    const files = await fs.readdir(API_DIR);
    
    const apis = await Promise.all(
      files.map(async (file) => {
        const stats = await fs.stat(path.join(API_DIR, file));
        // Extract timestamp from filename (api_[timestamp].php)
        const timestamp = parseInt(file.split('_')[1].split('.')[0]);
        return {
          fileName: file,
          timestamp: timestamp,
          size: stats.size
        };
      })
    );

    res.status(200).json({ success: true, apis });
  } catch (error) {
    console.error('Error listing API files:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to list API files',
      details: error.message 
    });
  }
});

// Delete API file
app.post('/api/delete-api', async (req, res) => {
  try {
    const { fileName } = req.body;
    const filePath = path.join(API_DIR, fileName);

    // Check if file exists
    try {
      await fs.access(filePath);
    } catch (error) {
      return res.status(404).json({
        success: false,
        error: 'API file not found'
      });
    }

    // Delete the file
    await fs.unlink(filePath);
    console.log('Successfully deleted API file:', fileName);

    res.status(200).json({
      success: true,
      message: 'API file deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting API file:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to delete API file',
      details: error.message 
    });
  }
});

// Get API file content
app.get('/api/get-api-content', async (req, res) => {
  try {
    const { fileName } = req.query;
    const filePath = path.join(API_DIR, fileName);

    // Check if file exists
    try {
      await fs.access(filePath);
    } catch (error) {
      return res.status(404).json({
        success: false,
        error: 'API file not found'
      });
    }

    // Read file content
    const content = await fs.readFile(filePath, 'utf8');
    
    res.status(200).json({
      success: true,
      content,
      fileName
    });
  } catch (error) {
    console.error('Error reading API file:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to read API file',
      details: error.message 
    });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.status(200).json({ status: 'Server is running' });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, async () => {
  await initializeFormDirectories();
  console.log(`Server running on port ${PORT}`);
  console.log(`Regular form submissions will be saved in: ${FORMS_DIR}`);
  console.log(`Form drilldown submissions will be saved in: ${FORMDRILLDOWN_DIR}`);
  console.log(`Form2 submissions will be saved in: ${FORM2_DIR}`);
  console.log(`API files will be saved in: ${API_DIR}`);
}); 