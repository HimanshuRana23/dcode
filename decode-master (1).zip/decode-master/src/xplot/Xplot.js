import React, { useState, useMemo } from 'react';
import './Xplot.css';
// import axios from 'axios';

export default function Xplot() {
  const [panels, setPanels] = useState([
    {
      title: '',
      datasource: '',
      panelType: 'stat',
      query: '',
      variableName: ''
    }
  ]);

  // Upload JSON handler
  const handleUploadJson = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target.result);
        // Support both {dashboard: {panels: ...}} and {panels: ...}
        const dashboard = json.dashboard || json;
        if (dashboard && Array.isArray(dashboard.panels)) {
          setPanels(
            dashboard.panels.map(panel => ({
              title: dashboard.title || '',
              datasource: panel.datasource?.uid || '',
              panelType: panel.type || 'stat',
              query: panel.targets?.[0]?.rawSql || '',
              variableName:
                (dashboard.templating?.list?.find(
                  v => v.datasource === panel.datasource?.uid
                )?.name) || ''
            }))
          );
        } else {
          alert('Invalid JSON structure: No panels found.');
        }
      } catch (err) {
        alert('Invalid JSON file.');
      }
    };
    reader.readAsText(file);
  };

  // Generate the JSON live as panels change
  const outputJson = useMemo(() => {
    return {
      dashboard: {
        id: null,
        uid: null,
        title: panels[0]?.title || '',
        timezone: "browser",
        schemaVersion: 30,
        version: 1,
        panels: panels.map((panel, idx) => ({
          type: panel.panelType,
          title: `Panel ${idx + 1}`,
          id: idx + 1,
          datasource: {
            type: "mysql",
            uid: panel.datasource
          },
          targets: [
            {
              refId: "A",
              format: "table",
              datasource: { uid: panel.datasource, type: "mysql" },
              rawSql: panel.query,
              rawQuery: true
            }
          ],
          gridPos: { x: 0, y: idx * 10, w: 24, h: 10 }
        })),
        templating: {
          list: panels.map((panel) => ({
            name: panel.variableName,
            label: panel.variableName,
            type: "query",
            datasource: panel.datasource,
            query: `SELECT DISTINCT ${panel.variableName} FROM your_table`,
            refresh: 1
          }))
        }
      },
      overwrite: true
    };
  }, [panels]);

  const handlePanelChange = (idx, e) => {
    const { name, value } = e.target;
    setPanels((prev) => prev.map((panel, i) => i === idx ? { ...panel, [name]: value } : panel));
  };

  const addPanel = () => {
    setPanels((prev) => [
      ...prev,
      {
        title: '',
        datasource: '',
        panelType: 'stat',
        query: '',
        variableName: ''
      }
    ]);
  };

  return (
    <div className="xplot-form-container">
      <input
        type="file"
        accept=".json,application/json"
        style={{ margin: '16px 0' }}
        onChange={handleUploadJson}
      />
      <div className="xplot-panel-group-list">
        {panels.map((panel, idx) => (
          <div className="xplot-panel-row" key={idx}>
            <input
              name="title"
              placeholder="Dashboard Title"
              value={panel.title}
              onChange={e => handlePanelChange(idx, e)}
              required
            />
            <input
              name="datasource"
              placeholder="Datasource (UID)"
              value={panel.datasource}
              onChange={e => handlePanelChange(idx, e)}
              required
            />
            <select
              name="panelType"
              value={panel.panelType}
              onChange={e => handlePanelChange(idx, e)}
            >
              <option value="stat">Stat</option>
              <option value="barchart">Bar Chart</option>
              <option value="volkovlabs-echarts-panel">EChart</option>
            </select>
            <textarea
              name="query"
              placeholder="SQL Query"
              value={panel.query}
              onChange={e => handlePanelChange(idx, e)}
              required
            />
            <input
              name="variableName"
              placeholder="Variable Name"
              value={panel.variableName}
              onChange={e => handlePanelChange(idx, e)}
              required
            />
            {idx === panels.length - 1 && (
              <button
                type="button"
                className="xplot-add-panel-btn"
                onClick={addPanel}
                title="Add Panel"
              >
                +
              </button>
            )}
          </div>
        ))}
      </div>
      <div className="output-section">
        <h3>Generated JSON</h3>
        <pre className="output-code">
          {JSON.stringify(outputJson, null, 2)}
        </pre>
      </div>
    </div>
  );
}
