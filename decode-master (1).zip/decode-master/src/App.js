import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import './App.css';
import Home from './components/Home';
import ApiGenerator from './api/ApiGenerator';
import About from './components/About';
import Xplot from './xplot/Xplot';
import Xreport from './xreport/Xreport';
import Xdag from './xdag/Xdag';
import HomeApi from './api/HomeApi';
import ApiGenerator2 from './api/ApiGenerator2';
import ApiGeneratorDrillDown from './api/ApiGeneratorDrillDown';
import ValidationApiGenerator from './api/ValidationApiGenerator';
import ApiEditor from './apieditor/apiEditor';
import ListAPIs from './apieditor/listAPIs';
import Flow from './flowbuilder/Flow';
import ListFlow from './flowbuilder/ListFlow';
import ApiFlowBuilderList from './apibuilder/ApiFlowBuilderList';
import ApiFlowBuilder from './apibuilder/ApiFlowBuilder';
import FactoryIntelligence from './factoryintelligence/FactoryIntelligenc';
const App = () => {
  const [selectedFile, setSelectedFile] = useState(null);

  const handleFileSelect = (file) => {
    setSelectedFile(file);
  };

  return (
    <Router>
      <div className="app">
        {/* <Sidebar /> */}
        <div className="content-wrapper">
          {/* <TopBar /> */}
          <main className="main-content">
            <Routes>
              <Route path="/flows" element={<ListFlow />} />
              {/* <Route path="/flow/new" element={<Flow />} /> */}
              <Route path="/flow/:flowId" element={<Flow />} />
              <Route path="/api-flow-builder" element={<ApiFlowBuilderList />} />
              {/* <Route path="/api-flow-builder/new" element={<ApiFlowBuilder />} /> */}
              <Route path="/api-flow-builder/:flowId" element={<ApiFlowBuilder />} />
              <Route path="/" element={<Home />} />
              <Route path="/homeapi" element={<HomeApi />} />
              <Route path="/api-generator" element={<ApiGenerator />} />
              <Route path="/api-generator2" element={<ApiGenerator2 />} />
              <Route path="/api-generatordrilldown" element={<ApiGeneratorDrillDown />} />
              <Route path="/validation-api-generator" element={<ValidationApiGenerator />} />
              <Route path="/api-editor" element={<ApiEditor selectedFile={selectedFile} onFileSelect={handleFileSelect} />} />
              <Route path="/api-editor/:id" element={<ApiEditor selectedFile={selectedFile} onFileSelect={handleFileSelect} />} />
              <Route path="/list-apis" element={<ListAPIs onFileSelect={handleFileSelect} />} />
              <Route path="/about" element={<About />} />
              <Route path="/xplot" element={<Xplot />} />
              <Route path="/xreport" element={<Xreport />} />
              <Route path="/xdag" element={<Xdag />} />
              <Route path="/app/admin/Dcode" element={<Home />} />
              <Route path="/factoryintelligence" element={<FactoryIntelligence />} />
              <Route path="*" element={<Navigate to="/flows" replace />} />
            </Routes>
          </main>
        </div>
      </div>
    </Router>
  );
};

export default App;
