import React, { useState } from 'react';

// Define node groups and icons
export const nodeGroups = {
  activity: [
    { key: 'dice', label: 'DICE', icon: '🎲' },
    { key: 'secondaryForm', label: 'Secondary Form', icon: '📄' },
    { key: 'information', label: 'Information', icon: 'ℹ️' },
    { key: 'subForm', label: 'Sub Form', icon: '🗂️' },
    { key: 'action', label: 'Action', icon: '🅰️' },
    { key: 'schedule', label: 'Schedule', icon: '📅' },
    { key: 'processTerminate', label: 'Process Terminate', icon: '⛔' },
    { key: 'processCategorisation', label: 'Process Categorisation', icon: '🗂️' },
    { key: 'ifBlock', label: 'If Block', icon: '🔀' },
  ],
  fourm: [
    { key: 'users', label: 'Users', icon: '👥' },
    { key: 'approvers', label: 'Approvers', icon: '📝' },
    { key: 'monitorUsers', label: 'Monitor Users', icon: '👥' },
    { key: 'machine', label: 'Machine', icon: '🏭' },
    { key: 'material', label: 'Material', icon: '⚙️' },
    { key: 'method', label: 'Method', icon: '📁' },
    { key: 'sequentialApprover', label: 'Sequential Approver', icon: '🗂️' },
  ],
  automation: [
    { key: 'notification', label: 'Notification', icon: '🔔' },
    { key: 'delayNotification', label: 'Delay Notification', icon: '⏰' },
    { key: 'bulkUpload', label: 'Bulk Upload', icon: '📊' },
    { key: 'sap', label: 'SAP', icon: '💼' },
    { key: 'bot', label: 'Bot', icon: '🤖' },
    { key: 'iotAlarms', label: 'IOT alarms', icon: '🚨' },
  ],
};

export const nodeTypes = {
  dice: {
    label: 'DICE Node',
    type: 'dice',
    group: 'activity',
  },
  secondaryForm: {
    label: 'Secondary Form',
    type: 'secondaryForm',
    group: 'activity',
  },
  information: {
    label: 'Information',
    type: 'information',
    group: 'activity',
  },
  subForm: {
    label: 'Sub Form',
    type: 'subForm',
    group: 'activity',
  },
  action: {
    label: 'Action',
    type: 'action',
    group: 'activity',
  },
  schedule: {
    label: 'Schedule',
    type: 'schedule',
    group: 'activity',
  },
  processTerminate: {
    label: 'Process Terminate',
    type: 'processTerminate',
    group: 'activity',
  },
  processCategorisation: {
    label: 'Process Categorisation',
    type: 'processCategorisation',
    group: 'activity',
  },
  ifBlock: {
    label: 'If Block',
    type: 'ifBlock',
    group: 'activity',
  },
  users: {
    label: 'Users',
    type: 'users',
    group: 'fourm',
  },
  approvers: {
    label: 'Approvers',
    type: 'approvers',
    group: 'fourm',
  },
  monitorUsers: {
    label: 'Monitor Users',
    type: 'monitorUsers',
    group: 'fourm',
  },
  machine: {
    label: 'Machine',
    type: 'machine',
    group: 'fourm',
  },
  material: {
    label: 'Material',
    type: 'material',
    group: 'fourm',
  },
  method: {
    label: 'Method',
    type: 'method',
    group: 'fourm',
  },
  sequentialApprover: {
    label: 'Sequential Approver',
    type: 'sequentialApprover',
    group: 'fourm',
  },
  notification: {
    label: 'Notification',
    type: 'notification',
    group: 'automation',
  },
  delayNotification: {
    label: 'Delay Notification',
    type: 'delayNotification',
    group: 'automation',
  },
  bulkUpload: {
    label: 'Bulk Upload',
    type: 'bulkUpload',
    group: 'automation',
  },
  sap: {
    label: 'SAP',
    type: 'sap',
    group: 'automation',
  },
  bot: {
    label: 'Bot',
    type: 'bot',
    group: 'automation',
  },
  iotAlarms: {
    label: 'IOT alarms',
    type: 'iotAlarms',
    group: 'automation',
  },
  // Add 4M and Automation nodes here as needed
};

const tabLabels = [
  { key: 'activity', label: 'Activity' },
  { key: 'fourm', label: '4M' },
  { key: 'automation', label: 'Automation' },
];

const Sidebar = () => {
  const [activeTab, setActiveTab] = useState('activity');

  const onDragStart = (event, nodeType) => {
    event.dataTransfer.setData('application/reactflow', nodeType);
    event.dataTransfer.effectAllowed = 'move';
  };

  const renderTabNodes = (tabKey) => {
    const nodes = nodeGroups[tabKey] || [];
    return (
      <div style={{ padding: '10px' }}>
        {nodes.length === 0 && (
          <div style={{ color: '#888', fontSize: '13px', marginTop: '20px' }}>No nodes available.</div>
        )}
        {nodes.map((node) => (
          <div
            key={node.key}
            className="dndnode"
            onDragStart={(event) => onDragStart(event, node.key)}
            draggable
            style={{
              border: '1px solid #ddd',
              padding: '12px',
              marginBottom: '12px',
              borderRadius: '6px',
              cursor: 'grab',
              backgroundColor: '#f8f8f8',
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              fontSize: '15px',
              transition: 'all 0.2s ease',
            }}
          >
            <span style={{ fontSize: '22px', width: '28px', textAlign: 'center' }}>{node.icon}</span>
            <span>{node.label}</span>
          </div>
        ))}
      </div>
    );
  };

  return (
    <aside style={{
      width: 260,
      padding: 0,
      borderRight: '1px solid #eee',
      backgroundColor: 'white',
      height: '100%',
      boxShadow: '2px 0 5px rgba(0,0,0,0.05)',
      display: 'flex',
      flexDirection: 'column',
    }}>
      <div style={{
        display: 'flex',
        borderBottom: '1px solid #eee',
        background: '#fafbfc',
      }}>
        {tabLabels.map((tab) => (
          <div
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            style={{
              flex: 1,
              padding: '16px 0',
              textAlign: 'center',
              cursor: 'pointer',
              fontWeight: activeTab === tab.key ? 'bold' : 'normal',
              borderBottom: activeTab === tab.key ? '3px solid #2d7ff9' : '3px solid transparent',
              color: activeTab === tab.key ? '#2d7ff9' : '#333',
              fontSize: '13px',
              background: activeTab === tab.key ? '#fff' : 'transparent',
              transition: 'all 0.2s',
            }}
          >
            {tab.label}
          </div>
        ))}
      </div>
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {renderTabNodes(activeTab)}
      </div>
    </aside>
  );
};

export default Sidebar; 