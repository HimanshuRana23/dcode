import React, { useState, useEffect } from 'react';
import RightSideBarConfig from '../RightSideBarConfig';

function ActionNodeConfig({ node, onSave, onClose }) {
  const [config, setConfig] = useState({
    actionType: '',
    actionName: '',
    parameters: '',
    description: ''
  });

  useEffect(() => {
    if (node.data.config) {
      const config = typeof node.data.config === 'string' ? JSON.parse(node.data.config) : node.data.config;
      setConfig(config);
    }
  }, [node]);

  const handleSave = () => {
    onSave(node.id, config);
  };

  return (
    <RightSideBarConfig
      title="Action Node Configuration"
      onSave={handleSave}
      onClose={onClose}
    >
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <div>
          <label style={{ display: 'block', marginBottom: '8px' }}>Action Type</label>
          <select
            value={config.actionType}
            onChange={(e) => setConfig({ ...config, actionType: e.target.value })}
            style={{
              width: '100%',
              padding: '8px',
              borderRadius: '4px',
              border: '1px solid #ddd'
            }}
          >
            <option value="">Select Action Type</option>
            <option value="api">API Call</option>
            <option value="email">Send Email</option>
            <option value="notification">Send Notification</option>
            <option value="database">Database Operation</option>
            <option value="custom">Custom Action</option>
          </select>
        </div>
        <div>
          <label style={{ display: 'block', marginBottom: '8px' }}>Action Name</label>
          <input
            type="text"
            value={config.actionName}
            onChange={(e) => setConfig({ ...config, actionName: e.target.value })}
            style={{
              width: '100%',
              padding: '8px',
              borderRadius: '4px',
              border: '1px solid #ddd'
            }}
            placeholder="Enter action name"
          />
        </div>
        <div>
          <label style={{ display: 'block', marginBottom: '8px' }}>Parameters</label>
          <textarea
            value={config.parameters}
            onChange={(e) => setConfig({ ...config, parameters: e.target.value })}
            style={{
              width: '100%',
              height: '100px',
              padding: '8px',
              borderRadius: '4px',
              border: '1px solid #ddd',
              resize: 'vertical'
            }}
            placeholder="Enter action parameters (JSON format)"
          />
        </div>
        <div>
          <label style={{ display: 'block', marginBottom: '8px' }}>Description</label>
          <textarea
            value={config.description}
            onChange={(e) => setConfig({ ...config, description: e.target.value })}
            style={{
              width: '100%',
              height: '100px',
              padding: '8px',
              borderRadius: '4px',
              border: '1px solid #ddd',
              resize: 'vertical'
            }}
            placeholder="Enter action description"
          />
        </div>
      </div>
    </RightSideBarConfig>
  );
}

export default ActionNodeConfig; 