import React, { useState, useEffect } from 'react';
import RightSideBarConfig from '../RightSideBarConfig';

function DiceNodeConfig({ node, onSave, onClose }) {
  const [formName, setFormName] = useState('');
  const [formType, setFormType] = useState('Regular');
  const [controlNumber, setControlNumber] = useState('');
  const [sequenceWiseAudit, setSequenceWiseAudit] = useState(false);
  const [sectionWiseAudit, setSectionWiseAudit] = useState(false);
  const [mandatoryNCClose, setMandatoryNCClose] = useState(false);
  const [signature, setSignature] = useState(false);
  const [isHiraChecksheet, setIsHiraChecksheet] = useState(false);

  useEffect(() => {
    if (node.data.config) {
      try {
        const config = typeof node.data.config === 'string' ? JSON.parse(node.data.config) : node.data.config;
        setFormName(config.formName || '');
        setFormType(config.formType || 'Regular');
        setControlNumber(config.controlNumber || '');
        setSequenceWiseAudit(!!config.sequenceWiseAudit);
        setSectionWiseAudit(!!config.sectionWiseAudit);
        setMandatoryNCClose(!!config.mandatoryNCClose);
        setSignature(!!config.signature);
        setIsHiraChecksheet(!!config.isHiraChecksheet);
      } catch (e) {
        console.error('Error parsing node config:', e);
      }
    }
  }, [node]);

  const handleSave = () => {
    const config = {
      formName,
      formType,
      controlNumber,
      sequenceWiseAudit,
      sectionWiseAudit,
      mandatoryNCClose,
      signature,
      isHiraChecksheet
    };
    onSave(node.id, JSON.stringify(config));
  };

  return (
    <RightSideBarConfig
      title="DICE Node Configuration"
      onSave={handleSave}
      onClose={onClose}
    >
      <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
        {/* Form Name */}
        <div>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', color: '#1a192b' }}>
            Form Name
          </label>
          <input
            type="text"
            value={formName}
            onChange={(e) => setFormName(e.target.value)}
            style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ddd', fontSize: '15px' }}
            placeholder="Enter form name"
          />
        </div>
        {/* Form Type */}
        <div>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', color: '#1a192b' }}>
            Form Type
          </label>
          <select
            value={formType}
            onChange={(e) => setFormType(e.target.value)}
            style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ddd', fontSize: '15px', backgroundColor: 'white' }}
          >
            <option value="Regular">Regular</option>
            <option value="Checklist">Checklist</option>
            <option value="Checksheet">Checksheet</option>
            <option value="Audit">Audit</option>
            <option value="Other">Other</option>
          </select>
        </div>
        {/* Control Number */}
        <div>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', color: '#1a192b' }}>
            Control Number
          </label>
          <input
            type="text"
            value={controlNumber}
            onChange={(e) => setControlNumber(e.target.value)}
            style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ddd', fontSize: '15px' }}
            placeholder="Enter control number"
          />
        </div>
        {/* Checkboxes */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px' }}>
          <div style={{ flex: '1 1 220px' }}>
            <input type="checkbox" id="sequenceWiseAudit" checked={sequenceWiseAudit} onChange={e => setSequenceWiseAudit(e.target.checked)} />
            <label htmlFor="sequenceWiseAudit" style={{ marginLeft: 8 }}>Enable Sequence Wise Audit</label>
          </div>
          <div style={{ flex: '1 1 220px' }}>
            <input type="checkbox" id="signature" checked={signature} onChange={e => setSignature(e.target.checked)} />
            <label htmlFor="signature" style={{ marginLeft: 8 }}>Enable Signature</label>
          </div>
          <div style={{ flex: '1 1 220px' }}>
            <input type="checkbox" id="sectionWiseAudit" checked={sectionWiseAudit} onChange={e => setSectionWiseAudit(e.target.checked)} />
            <label htmlFor="sectionWiseAudit" style={{ marginLeft: 8 }}>Enable Section Wise Audit</label>
          </div>
          <div style={{ flex: '1 1 220px' }}>
            <input type="checkbox" id="isHiraChecksheet" checked={isHiraChecksheet} onChange={e => setIsHiraChecksheet(e.target.checked)} />
            <label htmlFor="isHiraChecksheet" style={{ marginLeft: 8 }}>Is Hira Checksheet</label>
          </div>
          <div style={{ flex: '1 1 220px' }}>
            <input type="checkbox" id="mandatoryNCClose" checked={mandatoryNCClose} onChange={e => setMandatoryNCClose(e.target.checked)} />
            <label htmlFor="mandatoryNCClose" style={{ marginLeft: 8 }}>Enable Mandatory NC Close</label>
          </div>
        </div>
        {/* Buttons */}
        <div style={{ display: 'flex', gap: '16px', marginTop: '12px' }}>
          <button
            type="button"
            style={{ background: '#2176ae', color: 'white', border: 'none', borderRadius: '4px', padding: '10px 28px', fontWeight: 500, fontSize: 16, cursor: 'pointer' }}
            onClick={handleSave}
          >
            Add
          </button>
          <button
            type="button"
            style={{ background: '#23c483', color: 'white', border: 'none', borderRadius: '4px', padding: '10px 28px', fontWeight: 500, fontSize: 16, cursor: 'pointer' }}
            // onClick={...} // Add your handler here
          >
            Add Main Form Questions
          </button>
        </div>
      </div>
    </RightSideBarConfig>
  );
}

export default DiceNodeConfig; 