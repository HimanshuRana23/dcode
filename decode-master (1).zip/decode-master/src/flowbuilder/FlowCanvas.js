import React, { useCallback, useState } from 'react';
import { ReactFlow, Controls, Background } from '@xyflow/react';
import CustomNode from './CustomNode';

function FlowCanvas({
  nodes,
  setNodes,
  onNodesChange,
  edges,
  setEdges,
  onEdgesChange,
  onConnect,
  onNodeClick,
  onNodeDoubleClick,
  onEdgeClick,
  onPaneClick,
  nodeTypes,
  nodeConfigs,
  nodeGroups,
  showConfig,
  selectedNode,
  renderNodeConfig,
  onSave,
  flowName,
  setFlowName,
  flowId,
}) {
  const [rfInstance, setRfInstance] = useState(null);

  const onInit = useCallback((instance) => {
    console.log('ReactFlow onInit instance:', instance);
    setRfInstance(instance);
  }, []);

  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();
      const type = event.dataTransfer.getData('application/reactflow');
      console.log('onDrop fired, type:', type);
      if (!type) return;
      if (!rfInstance) {
        console.warn('rfInstance is not available yet');
        return;
      }
      if (typeof rfInstance.screenToFlowPosition !== 'function') {
        console.warn('rfInstance.screenToFlowPosition is not a function', rfInstance);
        return;
      }
      const position = rfInstance.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });
      const nodeConfig = nodeConfigs[type];
      if (!nodeConfig) {
        console.log('Node config not found for type:', type);
        return;
      }
      let icon = '';
      for (const group of Object.values(nodeGroups)) {
        const found = group.find((n) => n.key === type);
        if (found) {
          icon = found.icon;
          break;
        }
      }
      const newNode = {
        id: `${type}-${nodes.length + 1}`,
        type: 'custom',
        position,
        data: {
          label: nodeConfig.label,
          config: '',
          nodeType: type,
          icon,
        },
      };
      setNodes((nds) => {
        console.log('Adding node:', newNode);
        return nds.concat(newNode);
      });
    },
    [nodes, setNodes, nodeConfigs, nodeGroups, rfInstance]
  );

  return (
    <div style={{ flex: 1, position: 'relative', minHeight: '100vh', background: '#f6f7fb' }}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onDragOver={onDragOver}
        onDrop={onDrop}
        onNodeClick={onNodeClick}
        onNodeDoubleClick={onNodeDoubleClick}
        onEdgeClick={onEdgeClick}
        onPaneClick={onPaneClick}
        nodeTypes={nodeTypes}
        defaultEdgeOptions={{ type: 'default' }}
        style={{ minHeight: '100vh', background: '#fff' }}
        defaultViewport={{ x: 0, y: 0, zoom: 1 }}
        onInit={onInit}
      >
        <Controls />
        <Background />
      </ReactFlow>
      {nodes.length === 0 && (
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          color: '#bbb',
          fontSize: 24,
          pointerEvents: 'none',
          zIndex: 10
        }}>
          Drag nodes here to start building your flow!
        </div>
      )}
      {showConfig && selectedNode && (
        <div style={{
          position: 'absolute',
          top: 0,
          right: 0,
          bottom: 0,
          width: '50%',
          zIndex: 5,
          overflow: 'hidden'
        }}>
          {renderNodeConfig()}
        </div>
      )}
    </div>
  );
}

export default FlowCanvas; 