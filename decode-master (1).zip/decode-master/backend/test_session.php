<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/database.php';

try {
    $conn = getDBConnection();
    
    // Get the default user ID
    $stmt = $conn->query("SELECT id FROM users WHERE email = 'test@example.com'");
    $userId = $stmt->fetchColumn();
    
    if (!$userId) {
        throw new Exception("Default user not found. Please run the database.sql script first.");
    }
    
    // Test data
    $title = "Test Chat Session";
    
    // Insert test session
    $stmt = $conn->prepare("INSERT INTO chat_sessions (user_id, title) VALUES (?, ?)");
    $stmt->execute([$userId, $title]);
    
    $sessionId = $conn->lastInsertId();
    
    echo "Test session created successfully!<br>";
    echo "Session ID: " . $sessionId . "<br>";
    
    // Verify the session was created
    $stmt = $conn->prepare("SELECT * FROM chat_sessions WHERE session_id = ?");
    $stmt->execute([$sessionId]);
    $session = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<br>Session details:<br>";
    print_r($session);
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
} 