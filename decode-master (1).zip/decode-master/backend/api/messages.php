<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$conn = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw_data = file_get_contents('php://input');
    error_log("Received POST data: " . $raw_data);
    
    $data = json_decode($raw_data, true);
    
    if (!isset($data['sessionId']) || !isset($data['content']) || !isset($data['type'])) {
        error_log("Missing required fields. Received data: " . print_r($data, true));
        http_response_code(400);
        echo json_encode(['error' => 'Missing required fields']);
        exit();
    }

    try {
        $stmt = $conn->prepare("INSERT INTO messages (session_id, content, type) VALUES (?, ?, ?)");
        $stmt->execute([$data['sessionId'], $data['content'], $data['type']]);
        
        $messageId = $conn->lastInsertId();
        
        echo json_encode([
            'messageId' => $messageId,
            'message' => 'Message saved successfully'
        ]);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Failed to save message: ' . $e->getMessage()]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!isset($_GET['sessionId'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Session ID is required']);
        exit();
    }

    try {
        $stmt = $conn->prepare("SELECT * FROM messages WHERE session_id = ? ORDER BY created_at ASC");
        $stmt->execute([$_GET['sessionId']]);
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode($messages);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Failed to fetch messages: ' . $e->getMessage()]);
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
} 