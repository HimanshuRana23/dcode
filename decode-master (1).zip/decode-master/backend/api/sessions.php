<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

try {
    require_once '../config/database.php';

    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit();
    }

    $conn = getDBConnection();

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Get all sessions with their latest message, only not deleted
        $query = "SELECT cs.*, 
                    (SELECT content FROM messages 
                     WHERE session_id = cs.session_id 
                     ORDER BY created_at DESC LIMIT 1) as last_message,
                    (SELECT created_at FROM messages 
                     WHERE session_id = cs.session_id 
                     ORDER BY created_at DESC LIMIT 1) as last_message_time
                 FROM chat_sessions cs
                 WHERE cs.deleted = 0
                 ORDER BY cs.created_at DESC";
        $stmt = $conn->query($query);
        $sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (!is_array($sessions)) {
            $sessions = [];
        }
        echo json_encode($sessions);
    }
    else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $raw_data = file_get_contents('php://input');
        error_log("Received POST data: " . $raw_data);
        $data = json_decode($raw_data, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Invalid JSON data: ' . json_last_error_msg());
        }
        if (!isset($data['userId']) || !isset($data['title'])) {
            throw new Exception('Missing required fields. Received data: ' . print_r($data, true));
        }
        $tables = $conn->query("SHOW TABLES LIKE 'chat_sessions'")->fetchAll();
        if (empty($tables)) {
            throw new Exception('chat_sessions table does not exist');
        }
        $stmt = $conn->prepare("INSERT INTO chat_sessions (user_id, title) VALUES (?, ?)");
        $stmt->execute([$data['userId'], $data['title']]);
        $sessionId = $conn->lastInsertId();
        echo json_encode([
            'sessionId' => $sessionId,
            'message' => 'Session created successfully'
        ]);
    }
    else if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
        // Soft delete a session
        $raw_data = file_get_contents('php://input');
        $data = json_decode($raw_data, true);
        if (!isset($data['sessionId'])) {
            throw new Exception('Missing sessionId for delete');
        }
        $stmt = $conn->prepare("UPDATE chat_sessions SET deleted = 1 WHERE session_id = ?");
        $stmt->execute([$data['sessionId']]);
        echo json_encode(['message' => 'Session soft deleted']);
    }
    else {
        throw new Exception('Method not allowed');
    }
} catch (Exception $e) {
    error_log("Error in sessions.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
} 