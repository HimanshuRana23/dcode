# Factory Intelligence Backend

This is the PHP backend for the Factory Intelligence chat application.

## Setup Instructions

1. Create a MySQL database named `factory_intelligence`
2. Import the database structure from `database.sql`
3. Update the database credentials in `config/database.php`
4. Make sure your PHP server has PDO and MySQL extensions enabled
5. Place the files in your web server directory
6. Update the `API_URL` in your React frontend to point to your PHP backend

## API Endpoints

### Sessions
- POST `/api/sessions.php`
  - Creates a new chat session
  - Required fields: userId, title
  - Returns: sessionId

### Messages
- POST `/api/messages.php`
  - Saves a new message
  - Required fields: sessionId, content, type
  - Returns: messageId

- GET `/api/messages.php?sessionId={id}`
  - Retrieves all messages for a session
  - Required parameter: sessionId
  - Returns: Array of messages

## Database Structure

### chat_sessions
- session_id (INT, Primary Key)
- user_id (INT)
- title (VARCHAR)
- created_at (TIMESTAMP)

### messages
- message_id (INT, Primary Key)
- session_id (INT, Foreign Key)
- content (TEXT)
- type (ENUM: 'user', 'bot')
- created_at (TIMESTAMP)
